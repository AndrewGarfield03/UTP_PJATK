package com.company.assignment10.repositories;

import com.company.assignment10.dtos.UserDTO;

import java.util.List;

public interface IUserRepository extends IRepository<UserDTO> {

	List<UserDTO> findByName(String username);
	//List<User> findByName(String query);
	UserDTO findById(int id);
	void add(UserDTO user);
	void update(UserDTO user);
	void delete(UserDTO user);
}