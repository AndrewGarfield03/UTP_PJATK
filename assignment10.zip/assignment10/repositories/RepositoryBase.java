package com.company.assignment10.repositories;

import com.company.assignment10.Assignment10Exception;
import com.company.assignment10.dtos.DTOBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public abstract class RepositoryBase<TDTO extends DTOBase, TRepository extends IRepository<TDTO>> implements IRepository  {
    protected final String TABLE_GROUPS = "GROUPS";
    protected final String COLUMN_GROUP_ID = "GROUP_ID";
    protected final String COLUMN_GROUP_NAME = "GROUP_NAME";
    protected final String COLUMN_GROUP_DESCRIPTION = "GROUP_DESCRIPTION";

    protected final String TABLE_GROUPS_USERS = "GROUPS_USERS";
    protected final String TABLE_USERS = "USERS";
    protected final String COLUMN_USER_ID = "USER_ID";
    protected final String COLUMN_USER_LOGIN = "USER_LOGIN";
    protected final String COLUMN_USER_PASS = "USER_PASSWORD";
    protected final String VALUES = "VALUES";

    public Connection getConn() {
        return this.conn;
    }

    private Connection conn;
    @Override
    public Connection getConnection() {
        //Load the driver class
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Unable to load the class. Terminating the program");
            System.exit(-1);
        }
        //get the connection
        try {
            this.conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe","andrey","andrey");
            //String dbURL = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=TestDB";
            //connection = DriverManager.getConnection(URL, user, password);
            /*if (connection != null) {
                DatabaseMetaData dm = (DatabaseMetaData) connection.getMetaData();
                System.out.println("Driver name: " + dm.getDriverName());
                System.out.println("Driver version: " + dm.getDriverVersion());
                System.out.println("Product name: " + dm.getDatabaseProductName());
                System.out.println("Product version: " + dm.getDatabaseProductVersion());
            }*/

        } catch (SQLException ex) {
            System.out.println("Error getting connection: " + ex.getMessage());
            System.exit(-1);
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
            System.exit(-1);
        }
        return this.conn;
    }

    @Override
    public void add(DTOBase dto) {

    }

    @Override
    public void update(DTOBase dto) {

    }

    @Override
    public void addOrUpdate(DTOBase dto) {

    }

    @Override
    public void delete(DTOBase dto) {

    }

    @Override
    public DTOBase findById(int id) {
        return null;
    }

    @Override
    public void beginTransaction() {
        try {
            if (this.conn != null && !this.conn.isClosed())
                this.conn.setAutoCommit(false);
        }
        catch(SQLException ex)
        {
            throw new Assignment10Exception();
        }
    }

    @Override
    public void commitTransaction() {
        try {
            if (this.conn != null && !this.conn.isClosed())
                this.conn.commit();
        }
        catch(SQLException ex)
        {
            throw new Assignment10Exception();
        }
    }

    @Override
    public void rollbackTransaction() {
        try {
            if (this.conn != null && !this.conn.isClosed())
                this.conn.rollback();
        }
        catch(SQLException ex)
        {
            throw new Assignment10Exception();
        }
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public boolean exists(DTOBase dto) {
        return false;
    }
}
