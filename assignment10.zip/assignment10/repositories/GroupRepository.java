package com.company.assignment10.repositories;

import com.company.assignment10.Assignment10Exception;
import com.company.assignment10.dtos.DTOBase;
import com.company.assignment10.dtos.GroupDTO;
import com.company.assignment10.dtos.UserDTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GroupRepository extends RepositoryBase<GroupDTO, IGroupRepository> {

    @Override
    public void add(DTOBase dto) {
        GroupDTO groupDTO = (GroupDTO)dto;
        try {
            final String statementString = "INSERT INTO " + this.TABLE_GROUPS + " ("
                    + this.COLUMN_GROUP_ID + ","
                    + this.COLUMN_GROUP_NAME + ","
                    + this.COLUMN_GROUP_DESCRIPTION
                    + ") " + this.VALUES
                    + " (" +sequenceNextValue() + ",?,?)";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setString(1, groupDTO.getName());
            statement.setString(2, groupDTO.getDescription());
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
/*        finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
    }

    @Override
    public void update(DTOBase dto) {
        GroupDTO groupDTO = (GroupDTO)dto;
        try {
            final String statementString = "UPDATE " + this.TABLE_GROUPS
                    + " SET "
                    + this.COLUMN_GROUP_NAME + " =?, "
                    + this.COLUMN_GROUP_DESCRIPTION + " =? "
                    + " WHERE "
                    + this.COLUMN_GROUP_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setString(1, groupDTO.getName());
            statement.setString(2, groupDTO.getDescription());
            statement.setInt(3, groupDTO.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
        /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
    }

    @Override
    public void delete(DTOBase dto) {
        GroupDTO groupDTO = (GroupDTO)dto;
        try {
            final String statementString = "DELETE " + this.TABLE_GROUPS
                    + " WHERE "
                    + this.COLUMN_GROUP_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, groupDTO.getId());

            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
     /*   finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
    }

    @Override
    public void addOrUpdate(DTOBase dto) {
        if (exists(dto)) {
            update(dto);
        } else {
            add(dto);
        }
    }

    @Override
    public boolean exists(DTOBase dto){
        GroupDTO res = findById(dto.getId());
        return res != null;
    }

    @Override
    public GroupDTO findById(int id) {
        GroupDTO groupDTO = null;
        try {
            final String statementString = "SELECT "
                    + this.COLUMN_GROUP_ID + ","
                    + this.COLUMN_GROUP_NAME + ","
                    + this.COLUMN_GROUP_DESCRIPTION
                    + " FROM " + this.TABLE_GROUPS
                    + " WHERE "
                    + this.COLUMN_GROUP_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                groupDTO = new GroupDTO(rs.getInt(this.COLUMN_GROUP_ID), rs.getString(this.COLUMN_GROUP_NAME), rs.getString(this.COLUMN_GROUP_DESCRIPTION));
            }
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        } /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
*/
        return groupDTO;
    }


    @Override
    public int getCount() {
        int rowCount = 0;
        try {
            final String statementString = "SELECT COUNT(*) FROM " + this.TABLE_GROUPS;
            PreparedStatement statement = getConn().prepareStatement(statementString, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
                rowCount = rs.getInt(1);
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
    /*    finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
        return rowCount;
    }


    public List<GroupDTO> findByName(String name) {
        List<GroupDTO> groupDTOs = new ArrayList<>();
        try {

            final String statementString = "SELECT "
                    + this.COLUMN_GROUP_ID + ","
                    + this.COLUMN_GROUP_NAME + ","
                    + this.COLUMN_GROUP_DESCRIPTION
                    + " FROM " + this.TABLE_GROUPS
                    + " WHERE "
                    + this.COLUMN_GROUP_NAME + " LIKE \'"+name+"%\' ";

            PreparedStatement statement = getConn().prepareStatement(statementString);

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                GroupDTO groupDTO = new GroupDTO(rs.getInt(this.COLUMN_GROUP_ID), rs.getString(this.COLUMN_GROUP_NAME), rs.getString(this.COLUMN_GROUP_DESCRIPTION));
                groupDTOs.add(groupDTO);
            }
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        } /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
        return groupDTOs;
    }

    public List<UserDTO> getAllUsersForGroup(int groupId){
        List<UserDTO> userDTOs = new ArrayList<>();
        try {
            final String statementString = "SELECT "
                    + this.TABLE_USERS+"."+ this.COLUMN_USER_ID + ","
                    + this.TABLE_USERS+"."+ this.COLUMN_USER_LOGIN + ","
                    + this.TABLE_USERS+"."+ this.COLUMN_USER_PASS
                    + " FROM " + this.TABLE_GROUPS
                    + " INNER JOIN " +this.TABLE_GROUPS_USERS + " ON GROUPS.group_id = GROUPS_USERS.group_ID"
                    + " INNER JOIN "  +this.TABLE_USERS + " ON groups_users.user_id = users.user_id"
                    + " WHERE "
                    + this.TABLE_GROUPS +"."+ this.COLUMN_GROUP_ID + " =? "
                    + "ORDER BY " + this.TABLE_USERS+"."+ this.COLUMN_USER_ID;

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, groupId);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                UserDTO userDTO = new UserDTO(rs.getInt(this.COLUMN_USER_ID), rs.getString(this.COLUMN_USER_LOGIN), rs.getString(this.COLUMN_USER_PASS));
                userDTOs.add(userDTO);
            }
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
        return userDTOs;
    }


    public int sequenceNextValue(){
        return getCount() +1;
    }

}
