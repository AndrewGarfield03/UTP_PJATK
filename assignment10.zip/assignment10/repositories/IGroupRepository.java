package com.company.assignment10.repositories;

import com.company.assignment10.dtos.GroupDTO;

import java.util.List;

public interface IGroupRepository extends IRepository<GroupDTO> {

	List<GroupDTO> findByName(String name);
	GroupDTO findById(int id);
	void add(GroupDTO user);
	void update(GroupDTO user);
	void delete(GroupDTO user);
}