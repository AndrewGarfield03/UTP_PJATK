package com.company.assignment10.repositories;

import com.company.assignment10.Assignment10Exception;
import com.company.assignment10.dtos.DTOBase;
import com.company.assignment10.dtos.GroupDTO;
import com.company.assignment10.dtos.UserDTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserRepository extends RepositoryBase<UserDTO, IUserRepository> {


    public List<UserDTO> findByName(String username) {
        List<UserDTO> userDTOs = new ArrayList<>();

        try {
            final String statementString = "SELECT "
                    + this.COLUMN_USER_ID + ","
                    + this.COLUMN_USER_LOGIN + ","
                    + this.COLUMN_USER_PASS
                    + " FROM " + this.TABLE_USERS
                    + " WHERE "
                    + this.COLUMN_USER_LOGIN + " LIKE \'%"+username+"%\' ";

            PreparedStatement statement = getConn().prepareStatement(statementString);

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                UserDTO userDTO = new UserDTO(rs.getInt(this.COLUMN_USER_ID), rs.getString(this.COLUMN_USER_LOGIN), rs.getString(this.COLUMN_USER_PASS));
                userDTOs.add(userDTO);
            }
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }/* finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
        return userDTOs;
    }

    @Override
    public UserDTO findById(int id) {
        UserDTO userDTO = null;
        try {
            final String statementString = "SELECT "
                    + this.COLUMN_USER_ID + ","
                    + this.COLUMN_USER_LOGIN + ","
                    + this.COLUMN_USER_PASS
                    + " FROM " + this.TABLE_USERS
                    + " WHERE "
                    + this.COLUMN_USER_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                userDTO = new UserDTO(rs.getInt(this.COLUMN_USER_ID), rs.getString(this.COLUMN_USER_LOGIN), rs.getString(this.COLUMN_USER_PASS));
            }
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        } /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/

        return userDTO;

    }

    @Override
    public int getCount() {
        int rowCount = 0;
        try {
            final String statementString = "SELECT COUNT(*) FROM " + this.TABLE_USERS;
            PreparedStatement statement = getConn().prepareStatement(statementString, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
                rowCount = rs.getInt(1);
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
        /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
        return rowCount;
    }

    @Override
    public void add(DTOBase dto) {
        UserDTO user = (UserDTO)dto;
        try {
            final String statementString = "INSERT INTO " + this.TABLE_USERS + " ("
                    + this.COLUMN_USER_ID + ","
                    + this.COLUMN_USER_LOGIN + ","
                    + this.COLUMN_USER_PASS
                    + ") " + this.VALUES
                    + " (" +sequenceNextValue() + ",?,?)";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setString(1, user.getLogin());
            statement.setString(2, user.getPassword());
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
       /* finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
    }

    @Override
    public void update(DTOBase dto) {
        UserDTO user = (UserDTO)dto;
        try {
            final String statementString = "UPDATE " + this.TABLE_USERS
                    + " SET "
                    + this.COLUMN_USER_LOGIN + " =?, "
                    + this.COLUMN_USER_PASS + " =? "
                    + " WHERE "
                    + this.COLUMN_USER_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setString(1, user.getLogin());
            statement.setString(2, user.getPassword());
            statement.setInt(3, user.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
        /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
    }

    @Override
    public void delete(DTOBase dto) {
        UserDTO userDTO = (UserDTO)dto;
        try {
            final String statementString = "DELETE " + this.TABLE_USERS
                    + " WHERE "
                    + this.COLUMN_USER_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, userDTO.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
        /*finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
    }

    @Override
    public void addOrUpdate(DTOBase dto) {
        if (exists(dto)) {
            update(dto);
        } else {
            add(dto);
        }
    }

    @Override
    public boolean exists(DTOBase dto){
        UserDTO res = findById(dto.getId());
        return res != null;
    }

    public void addUserToGroup(int userId, int groupId){
        try {
            final String statementString = "INSERT INTO " + this.TABLE_GROUPS_USERS + " ("
                    + this.COLUMN_USER_ID + ","
                    + this.COLUMN_GROUP_ID
                    + ") " + this.VALUES
                    + " (?,?)";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, userId);
            statement.setInt(2, groupId);
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
    }

    public void deleteUserFromGroup(int userId, int groupId){
        try {
            final String statementString = "DELETE " + this.TABLE_GROUPS_USERS
                    + " WHERE "
                    + this.COLUMN_USER_ID + " =? "
                    + " AND "
                    + this.COLUMN_GROUP_ID + " =? ";

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, userId);
            statement.setInt(2, groupId);
            statement.executeUpdate();
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
    }

    public List<GroupDTO> getAllGroupsForUser(int userId){
        List<GroupDTO> groupDTOs = new ArrayList<>();
        try {
            final String statementString = "SELECT "
                    + this.TABLE_GROUPS+"."+ this.COLUMN_GROUP_ID + ","
                    + this.TABLE_GROUPS+"."+ this.COLUMN_GROUP_NAME + ","
                    + this.TABLE_GROUPS+"."+ this.COLUMN_GROUP_DESCRIPTION
                    + " FROM " + this.TABLE_USERS
                    + " INNER JOIN " +this.TABLE_GROUPS_USERS + " ON USERS.user_id = GROUPS_USERS.user_ID"
                    + " INNER JOIN "  +this.TABLE_GROUPS + " ON groups_users.group_id = groups.group_id"
                    + " WHERE "
                    + this.TABLE_USERS +"."+ this.COLUMN_USER_ID + " =? "
                    + "ORDER BY " + this.TABLE_GROUPS+"."+ this.COLUMN_GROUP_ID;

            PreparedStatement statement = getConn().prepareStatement(statementString);
            statement.setInt(1, userId);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                GroupDTO groupDTO = new GroupDTO(rs.getInt(this.COLUMN_GROUP_ID), rs.getString(this.COLUMN_GROUP_NAME), rs.getString(this.COLUMN_GROUP_DESCRIPTION));
                groupDTOs.add(groupDTO);
            }
        } catch (SQLException ex) {
            throw new Assignment10Exception();
        }
        return groupDTOs;
    }

    public int sequenceNextValue(){
        return getCount() +1;
    }
}
