package com.company.assignment10.test;

import com.company.assignment10.dtos.DTOBase;
import com.company.assignment10.dtos.GroupDTO;
import com.company.assignment10.dtos.UserDTO;
import com.company.assignment10.repositories.IUserRepository;
import com.company.assignment10.repositories.UserRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;
import java.util.List;

public final class UserRepositoryTest extends RepositoryTestBase<UserDTO, IUserRepository> {

	private UserRepository userRepository;

	@Before
	public void setUp()
	{
		this.userRepository = new UserRepository();
		this.userRepository.getConnection();
		this.userRepository.beginTransaction();
	}

	@After
	public void after(){
		try {
			if (this.userRepository.getConn() != null && !this.userRepository.getConn().isClosed()) {
				//this.groupRepository.commitTransaction();
				this.userRepository.rollbackTransaction();
				this.userRepository.getConn().close();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void add() {
		DTOBase dto = new UserDTO(2, "User_2_Name", "User_2_Password");
		int res = this.userRepository.getCount();
		int expected = res + 1;
		this.userRepository.add(dto);
		int result = this.userRepository.getCount();

		Assert.assertEquals(expected, result);
	}

	@Test
	public void update() {
		final String expectedPass = "User_test_Password";
		DTOBase dto = new UserDTO(1, "User_1_Name", expectedPass);
		this.userRepository.update(dto);
		UserDTO result = this.userRepository.findById(1);
		Assert.assertEquals(expectedPass, result.getPassword());
	}

	@Test
	public void addOrUpdate() {
		DTOBase dto = new UserDTO(2, "User_2_Name", "User_2_Password");
		int res = this.userRepository.getCount();
		int expected = res + 1;

		this.userRepository.addOrUpdate(dto);
		int result = this.userRepository.getCount();

		Assert.assertEquals(expected, result);
	}

	@Test
	public void delete() {
		DTOBase dto = new UserDTO(1, "User_1", "User_1_Password");
		int res = this.userRepository.getCount();
		int expected = res - 1;
		this.userRepository.delete(dto);
		int result = this.userRepository.getCount();

		Assert.assertEquals(expected, result);
	}

	@Test
	public void findById() {
		UserDTO result = this.userRepository.findById(1);
		Assert.assertEquals(1, result.getId());
		Assert.assertEquals("User_1", result.getLogin());
		Assert.assertEquals("User_1_Password", result.getPassword());
	}

	@Test
	public void findByName() {
		List<UserDTO> result = this.userRepository.findByName("User_1");
		Assert.assertEquals(1, result.size());
		Assert.assertEquals(1, result.get(0).getId());
		Assert.assertEquals("User_1", result.get(0).getLogin());
		Assert.assertEquals("User_1_Password", result.get(0).getPassword());
	}

	@Test
	public void addUserToGroup() {
		int userId = 1;
		int groupId = 3;
		this.userRepository.addUserToGroup(userId,groupId);

		List<GroupDTO> result = this.userRepository.getAllGroupsForUser(userId);

		Assert.assertEquals(3, result.size());
		Assert.assertEquals(1, result.get(0).getId());
		Assert.assertEquals("Group_1", result.get(0).getName());
		Assert.assertEquals("Group_1_Description", result.get(0).getDescription());

		Assert.assertEquals(2, result.get(1).getId());
		Assert.assertEquals("Group_3", result.get(1).getName());
		Assert.assertEquals("Group_3_Description", result.get(1).getDescription());
	}

	@Test
	public void deleteUserFromGroup() {
		int userId = 1;
		int groupId = 2;
		this.userRepository.deleteUserFromGroup(userId,groupId);

		List<GroupDTO> result = this.userRepository.getAllGroupsForUser(userId);

		Assert.assertEquals(1, result.size());
	}

	@Test
	public void getAllGroupsForUser() {
		int userId = 1;

		List<GroupDTO> result = this.userRepository.getAllGroupsForUser(userId);

		Assert.assertEquals(2, result.size());
	}

	@Override
	protected IUserRepository Create() {
		return null;
	}
}