package com.company.assignment10.test;

import com.company.assignment10.dtos.DTOBase;
import com.company.assignment10.dtos.GroupDTO;
import com.company.assignment10.dtos.UserDTO;
import com.company.assignment10.repositories.GroupRepository;
import com.company.assignment10.repositories.IGroupRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;
import java.util.List;

public class GroupRepositoryTest extends RepositoryTestBase<GroupDTO, IGroupRepository> {
	private GroupRepository groupRepository;

	@Before
	public void setUp()
	{
		this.groupRepository = new GroupRepository();
		this.groupRepository.getConnection();
		this.groupRepository.beginTransaction();
	}

	@After
	public void after(){
		try {
			if (this.groupRepository.getConn() != null && !this.groupRepository.getConn().isClosed()) {
				//this.groupRepository.commitTransaction();
				this.groupRepository.rollbackTransaction();
				this.groupRepository.getConn().close();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void add() {
		DTOBase dto = new GroupDTO(5, "Group_5", "Group_5_Description");
		int res = this.groupRepository.getCount();
		int expected = res + 1;
		this.groupRepository.add(dto);
		int result = this.groupRepository.getCount();

		Assert.assertEquals(expected, result);
	}

	@Test
	public void update() {
		String expectedDescription = "Group_5_Description";
		DTOBase dto = new GroupDTO(2, "Group_3", expectedDescription);
		this.groupRepository.update(dto);
		GroupDTO result = this.groupRepository.findById(2);
		Assert.assertEquals(expectedDescription, result.getDescription());
	}
	
	@Test
	public void addOrUpdate() {
		DTOBase dto = new GroupDTO(5, "Group_5", "Group_5_Description");
		int res = this.groupRepository.getCount();
		int expected = res + 1;

		this.groupRepository.addOrUpdate(dto);
		int result = this.groupRepository.getCount();

		Assert.assertEquals(expected, result);
	}

	@Test
	public void delete() {
		DTOBase dto = new GroupDTO(2, "Group_3", "Group_3_Description");
		int res = this.groupRepository.getCount();
		int expected = res - 1;
		this.groupRepository.delete(dto);
		int result = this.groupRepository.getCount();

		Assert.assertEquals(expected, result);
	}

	@Test
	public void findById() {
		GroupDTO result = this.groupRepository.findById(1);
		Assert.assertEquals(1, result.getId());
		Assert.assertEquals("Group_1", result.getName());
		Assert.assertEquals("Group_1_Description", result.getDescription());
	}
	
	@Test
	public void findByName() {
		List<GroupDTO> result = this.groupRepository.findByName("Group_1");
		Assert.assertEquals(1, result.size());
		Assert.assertEquals(1, result.get(0).getId());
		Assert.assertEquals("Group_1", result.get(0).getName());
		Assert.assertEquals("Group_1_Description", result.get(0).getDescription());
	}

	@Test
	public void getAllUsersForGroup() {
		int groupId = 1;

		List<UserDTO> result = this.groupRepository.getAllUsersForGroup(groupId);

		Assert.assertEquals(1, result.size());
	}

	@Override
	protected IGroupRepository Create() {
		return null;
	}
}