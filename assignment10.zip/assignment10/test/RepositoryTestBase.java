package com.company.assignment10.test;

import com.company.assignment10.dtos.DTOBase;
import com.company.assignment10.repositories.IRepository;
import org.junit.After;
import org.junit.Before;

public abstract class RepositoryTestBase<TDTO extends DTOBase, TRepository extends IRepository<TDTO>> {

	private TRepository repository;

	@Before
	public void before() {
		this.repository = Create();
		if (this.repository != null) {
			this.repository.beginTransaction();
		}
	}

	@After
	public void after() {
		if (this.repository != null) {
			this.repository.rollbackTransaction();
		}
	}

	protected abstract TRepository Create();
}