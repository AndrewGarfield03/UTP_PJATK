package com.company.assignment10.dtos;

import java.util.LinkedList;
import java.util.List;

public class GroupDTO extends DTOBase {

	private String _name;
	private String _description;
	private List<UserDTO> _users;

	public GroupDTO() {
	}

	public GroupDTO(int id, String name, String description) {
		super(id);
		this._name = name;
		this._description = description;
	}

	public String getName() {
		return this._name;
	}

	public void setName(String name) {
		this._name = name;
	}

	public String getDescription() {
		return this._description;
	}

	public void setDescription(String description) {
		this._description = description;
	}

	public List<UserDTO> getUsers() {
		return this._users;
	}

	public void setUsers(List<UserDTO> users) {
		this._users = users;
	}

	public void addUser(UserDTO user) {
		if (this._users == null) {
			this._users = new LinkedList<UserDTO>();
		}
		this._users.add(user);
	}

	public void deleteUser(UserDTO user) {
		if (this._users != null) {
			this._users.remove(user);
		}
	}
}