package com.company.assignment10.dtos;

import java.util.LinkedList;
import java.util.List;

public class UserDTO extends DTOBase {

	private String _login;
	private String _password;
	private List<GroupDTO> _groups;

	public UserDTO() {
	}
	public UserDTO(String login, String password) {
		this._login = login;
		this._password = password;
	}
	public UserDTO(int id, String login, String password) {
		super(id);
		this._login = login;
		this._password = password;
	}

	public String getLogin() {
		return this._login;
	}

	public void setLogin(String login) {
		this._login = login;
	}

	public String getPassword() {
		return this._password;
	}

	public void setPassword(String password) {
		this._password = password;
	}

	public List<GroupDTO> getGroups() {
		return this._groups;
	}

	public void setGroups(List<GroupDTO> groups) {
		this._groups = groups;
	}

	public void addGroup(GroupDTO group) {
		if (this._groups == null) {
			this._groups = new LinkedList<GroupDTO>();
		}
		this._groups.add(group);
	}

	public void deleteGroup(GroupDTO group) {
		if (this._groups != null) {
			this._groups.remove(group);
		}
	}
}