package com.company.assignment10.dtos;

public abstract class DTOBase {

	private int _id;

	protected DTOBase() {}

	protected DTOBase(int id) {
		this._id = id;
	}

	public int getId() {
		return this._id;
	}

	public void setId(int id) {
		this._id = id;
	}

	public boolean hasExistingId() {
		return getId() > 0;
	}
}