package com.company.assignment10;

public final class Assignment10Exception extends RuntimeException {

	private static final long serialVersionUID = -9136633471042484748L;
}